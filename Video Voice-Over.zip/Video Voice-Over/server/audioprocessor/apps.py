from django.apps import AppConfig


class AudioprocessorConfig(AppConfig):
    name = 'audioprocessor'
