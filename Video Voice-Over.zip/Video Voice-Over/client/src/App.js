// import Home from "./components/AudioProcessor";
import Home from "./components/Layout"; //this is for reactflow ffmpeg 
// import Home from "./components/example";
// import Home from "./Traverse/Home"
function App() {
  return (
    <div className="App">
    <Home/>
    </div>
  );
}

export default App;
