// import Home from "./components/Home";
import Home from "./components/Routes";
// import Home from "./components/example";
function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
